"""WhatsApp Cloud API gateway app.

``send`` preserves the direct text-message client via the Meta
Graph API at ``/{api_version}/{phone_number_id}/messages`` with a
Bearer access token.  Inbound (the verify-token + webhook receiver
HTTP server), lifecycle, Activity admission and safe replies are Root-owned.

Credentials needed:
  * ``whatsapp_access_token``        — Meta system-user / app token
  * ``whatsapp_phone_number_id``     — sender phone number id (NOT
                                       the phone number itself —
                                       this is a Meta-issued id
                                       attached to the WhatsApp
                                       Business Account)

Optional env override: ``COS_WHATSAPP_TOKEN``.

Stdlib only.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error


from gateway._shared import channels, gateway_memory, safe_egress, safe_subprocess


PLATFORM = "whatsapp"
USER_AGENT = "ClawOSWhatsApp/0.1.0 (+https://github.com/clawos/cos)"
GRAPH_API = "https://graph.facebook.com"
API_VERSION = "v21.0"
SOFT_LEN = 4096  # WhatsApp text body limit (per Meta docs, 4096 chars)


def _load_credential(name: str) -> tuple[str | None, str | None]:
    return safe_subprocess.safe_credential_load(name)


def _load_token() -> tuple[str | None, str | None]:
    env_tok = os.environ.get("COS_WHATSAPP_TOKEN")
    if env_tok:
        return env_tok.strip(), None
    return _load_credential("whatsapp_access_token")


def _load_phone_number_id() -> tuple[str | None, str | None]:
    env_id = os.environ.get("COS_WHATSAPP_PHONE_NUMBER_ID")
    if env_id:
        return env_id.strip(), None
    return _load_credential("whatsapp_phone_number_id")


def _truncate(text: str, limit: int = SOFT_LEN) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "\u2026"


def _normalise_phone(s: str) -> str:
    """Strip + and whitespace; Meta wants digits-only E.164."""
    return "".join(ch for ch in s if ch.isdigit())


def _send(recipient_phone: str, text: str) -> dict:
    if not recipient_phone or not str(recipient_phone).strip():
        return {"ok": False, "error": "recipient_phone required"}
    if not text or not str(text).strip():
        return {"ok": False, "error": "text required"}

    phone = _normalise_phone(str(recipient_phone))
    if not phone:
        return {
            "ok": False,
            "error": "recipient_phone has no digits after normalisation",
        }

    token, err = _load_token()
    if not token:
        return {"ok": False, "error": err or "no token"}
    pnid, err = _load_phone_number_id()
    if not pnid:
        return {"ok": False, "error": err or "no phone_number_id"}

    body = json.dumps(
        {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": phone,
            "type": "text",
            "text": {"body": _truncate(str(text)), "preview_url": False},
        }
    ).encode("utf-8")

    url = f"{GRAPH_API}/{API_VERSION}/{pnid}/messages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
    }
    try:
        _, _, raw_resp = safe_egress.safe_urlopen(
            "POST",
            url,
            headers=headers,
            body=body,
            timeout=15,
            verb_id="net.dial",
        )
        raw = raw_resp.decode("utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {"raw": raw}
        wamid = None
        if isinstance(data, dict):
            msgs = data.get("messages")
            if isinstance(msgs, list) and msgs:
                first = msgs[0]
                if isinstance(first, dict):
                    wamid = first.get("id")
        return {
            "ok": True,
            "platform": PLATFORM,
            "to": phone,
            "wamid": wamid,
        }
    except safe_egress.EgressBlocked as e:
        return {"ok": False, "platform": PLATFORM, "error": f"egress blocked: {e}"}
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            err_body = str(e)
        return {
            "ok": False,
            "platform": PLATFORM,
            "error": f"HTTP {e.code}: {err_body}",
        }
    except urllib.error.URLError as e:
        return {"ok": False, "platform": PLATFORM, "error": f"URL error: {e.reason}"}
    except Exception as e:
        denial = getattr(e, "denial", None)
        if denial is not None:
            return {"ok": False, "platform": PLATFORM, "error": "permission denied", "denial": denial}
        raise


def run(command: str, args):
    if command in {"status", "start", "stop", "reply"}:
        return channels.run(PLATFORM, command, args)
    from canonical_argv import normalize_canonical_argv
    if isinstance(args, list):
        args = normalize_canonical_argv(args)
    if command == "send":
        if isinstance(args, list):
            recipient = args[0] if len(args) > 0 else ""
            text = args[1] if len(args) > 1 else ""
        elif isinstance(args, dict):
            recipient = args.get("recipient_phone", "")
            text = args.get("text", "")
        else:
            return {"ok": False, "error": "invalid args"}
        result = _send(str(recipient), str(text))
        gateway_memory.remember_send(PLATFORM, result, channel_id=str(recipient), text=str(text))
        return result
    return {"ok": False, "error": f"unknown command: {command}"}


if __name__ == "__main__":
    cmd = os.environ.get("COS_COMMAND") or (sys.argv[1] if len(sys.argv) > 1 else "")
    raw_args = os.environ.get("COS_ARGS_JSON")
    if raw_args:
        parsed_args = json.loads(raw_args)
    else:
        parsed_args = sys.argv[2:]
    print(json.dumps(run(cmd, parsed_args)))
